def predict_disease(image_path):
    # Dummy prediction logic for now
    # Replace this with your actual model inference
    return "Leaf Spot", "Fungal disease causing black spots.", "Use Mancozeb or Neem oil."